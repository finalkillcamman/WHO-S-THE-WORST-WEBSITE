# Who's the Worst? website

This package includes the official adult and kids game-box images provided by the game creator, a responsive website, and the agreed gameplay rules.

## Publish to GitHub

Upload `index.html`, `styles.css`, and the entire `assets/` folder into the root of `finalkillcamman/WHO-S-THE-WORST-WEBSITE`. If prompted, replace the old `index.html` and `styles.css`. Do not delete other files in the repository.

In repository Settings > Pages, select Deploy from a branch, `main`, and `/ (root)`; save. Pages availability depends on repository visibility and plan.

The website has no tracking, login, API keys, or backend. The sample description of the editions can be adjusted before public launch.

## Real beta cards

The `assets/` folder includes the five original beta-card images supplied by the game creator. They appear in the hero background and in the Real Cards gallery. Keep the image paths intact when uploading to GitHub Pages.
